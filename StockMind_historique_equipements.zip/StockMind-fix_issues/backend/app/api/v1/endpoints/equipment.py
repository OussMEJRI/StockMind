from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func
from typing import List, Optional

from app.core.deps import get_db, get_current_active_user, require_roles
from app.models.user import UserRole
from app.models.equipment import Equipment as EquipmentModel
from app.models.employee import Employee
from app.models.employee_equipment_history import EmployeeEquipmentHistory
from app.schemas.equipment import EquipmentResponse, EquipmentCreate, EquipmentUpdate
from app.schemas.employee_equipment_history import HistoryResponse

router = APIRouter()

TYPE_MAP = {
    "pc":"PC","laptop":"LAPTOP","monitor":"MONITOR","phone":"PHONE",
    "printer":"ACCESSORY","other":"ACCESSORY","accessory":"ACCESSORY",
    "PC":"PC","LAPTOP":"LAPTOP","MONITOR":"MONITOR","PHONE":"PHONE","ACCESSORY":"ACCESSORY",
}
STATUS_MAP = {
    "in_stock": "IN_STOCK",
    "assigned": "ASSIGNED",
    "maintenance": "MAINTENANCE",
    "stolen": "STOLEN",

    # compatibilité ancienne valeur
    "retired": "STOLEN",

    "IN_STOCK": "IN_STOCK",
    "ASSIGNED": "ASSIGNED",
    "MAINTENANCE": "MAINTENANCE",
    "STOLEN": "STOLEN",
    "RETIRED": "STOLEN",
}
CONDITION_MAP = {
    "new":"NEW","good":"USED","fair":"USED","poor":"OUT_OF_SERVICE",
    "used":"USED","out_of_service":"OUT_OF_SERVICE",
    "NEW":"NEW","USED":"USED","OUT_OF_SERVICE":"OUT_OF_SERVICE",
}


def close_open_employee_history(db: Session, equipment_id: int, note: str = "Retrait de l'équipement") -> None:
    """Ferme l'affectation active d'un équipement dans l'historique."""
    from datetime import datetime, timezone

    open_history = db.query(EmployeeEquipmentHistory).filter(
        EmployeeEquipmentHistory.equipment_id == equipment_id,
        EmployeeEquipmentHistory.returned_at.is_(None)
    ).first()

    if open_history:
        open_history.returned_at = datetime.now(timezone.utc)
        if not open_history.notes:
            open_history.notes = note


def open_employee_history(db: Session, equipment_id: int, employee_id: int, note: str = "Affectation de l'équipement") -> None:
    """Crée une nouvelle ligne d'historique si l'équipement est affecté à un employé."""
    from datetime import datetime, timezone

    db.add(EmployeeEquipmentHistory(
        equipment_id=equipment_id,
        employee_id=employee_id,
        assigned_at=datetime.now(timezone.utc),
        notes=note
    ))


def sync_employee_assignment_history(
    db: Session,
    equipment: EquipmentModel,
    old_employee_id: Optional[int],
    new_employee_id: Optional[int]
) -> None:
    """
    Synchronise automatiquement l'historique :
    - si l'employé change, on ferme l'ancienne affectation ;
    - si un nouvel employé est défini, on ouvre une nouvelle affectation ;
    - si l'équipement est retiré, l'historique actif est fermé.
    """
    if old_employee_id == new_employee_id:
        return

    if old_employee_id is not None:
        close_open_employee_history(db, equipment.id)

    if new_employee_id is not None:
        open_employee_history(db, equipment.id, new_employee_id)

@router.get("", response_model=List[EquipmentResponse])
def get_equipment(
    skip: int = 0, limit: int = 100,
    equipment_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    condition: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_active_user)
):
    query = db.query(EquipmentModel)
    if equipment_type:
        query = query.filter(EquipmentModel.equipment_type == TYPE_MAP.get(equipment_type, equipment_type))
    if status:
        query = query.filter(EquipmentModel.status == STATUS_MAP.get(status, status))
    if condition:
        query = query.filter(EquipmentModel.condition == CONDITION_MAP.get(condition, condition))
    if search:
        query = query.filter(EquipmentModel.serial_number.ilike(f"%{search}%"))
    return query.offset(skip).limit(limit).all()

@router.post("", response_model=EquipmentResponse, status_code=201)
def create_equipment(
    equipment: EquipmentCreate,
    db: Session = Depends(get_db),
    _=Depends(get_current_active_user)
):
    existing = db.query(EquipmentModel).filter(
        EquipmentModel.serial_number == equipment.serial_number
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Serial number already exists")
    if equipment.status == "STOLEN":
        raise HTTPException(
           status_code=400,
           detail="Un équipement ne peut pas être créé directement avec le statut Volé"
            )
    db_eq = EquipmentModel(**equipment.dict())
    db.add(db_eq)
    db.flush()

    if db_eq.employee_id is not None:
        open_employee_history(db, db_eq.id, db_eq.employee_id, "Affectation initiale de l'équipement")

    db.commit()
    db.refresh(db_eq)
    return db_eq

@router.get("/nb_pcs/online")
def get_nb_pcs_online(db: Session = Depends(get_db), _=Depends(get_current_active_user)):
    nb = db.query(func.count(EquipmentModel.id)).filter(
        EquipmentModel.equipment_type.in_(["LAPTOP"]),
        EquipmentModel.status == "ASSIGNED"
    ).scalar()
    return {"nb_pcs": nb or 0}

@router.get("/by-serial/{serial_number}", response_model=EquipmentResponse)
def get_equipment_by_serial(
    serial_number: str,
    db: Session = Depends(get_db),
    _=Depends(get_current_active_user)
):
    eq = db.query(EquipmentModel).filter(EquipmentModel.serial_number == serial_number).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")
    return eq


@router.get("/{equipment_id}/history", response_model=List[HistoryResponse])
def get_equipment_history(
    equipment_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_active_user)
):
    """Récupérer l'historique complet d'affectation d'un équipement."""
    eq = db.query(EquipmentModel).filter(EquipmentModel.id == equipment_id).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")

    history = db.query(EmployeeEquipmentHistory).options(
        joinedload(EmployeeEquipmentHistory.employee),
        joinedload(EmployeeEquipmentHistory.equipment)
    ).filter(
        EmployeeEquipmentHistory.equipment_id == equipment_id
    ).order_by(EmployeeEquipmentHistory.assigned_at.desc()).all()

    result = []
    for h in history:
        result.append(HistoryResponse(
            id=h.id,
            employee_id=h.employee_id,
            equipment_id=h.equipment_id,
            assigned_at=h.assigned_at,
            returned_at=h.returned_at,
            notes=h.notes,
            created_at=h.created_at,
            equipment_serial=h.equipment.serial_number if h.equipment else None,
            equipment_model=h.equipment.model if h.equipment else None,
            equipment_type=h.equipment.equipment_type if h.equipment else None,
            employee_name=h.employee.name if h.employee else None,
            employee_cuid=h.employee.cuid if h.employee else None,
            employee_email=h.employee.email if h.employee else None,
        ))
    return result

@router.get("/{equipment_id}", response_model=EquipmentResponse)
def get_equipment_by_id(
    equipment_id: int,
    db: Session = Depends(get_db),
    _=Depends(get_current_active_user)
):
    eq = db.query(EquipmentModel).filter(EquipmentModel.id == equipment_id).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")
    return eq

@router.put("/{equipment_id}", response_model=EquipmentResponse)
def update_equipment(
    equipment_id: int,
    equipment: EquipmentUpdate,
    db: Session = Depends(get_db),
    _=Depends(get_current_active_user)
):
    db_eq = db.query(EquipmentModel).filter(EquipmentModel.id == equipment_id).first()
    if not db_eq:
        raise HTTPException(status_code=404, detail="Equipment not found")

    payload = equipment.dict(exclude_unset=True)

    target_type = payload.get("equipment_type", db_eq.equipment_type)
    is_laptop = str(target_type).upper() == "LAPTOP"

    requested_status = payload.get("status", db_eq.status)

    current_employee_id = payload["employee_id"] if "employee_id" in payload else db_eq.employee_id
    current_emplacement_id = payload["emplacement_id"] if "emplacement_id" in payload else db_eq.emplacement_id

    has_assignment = bool(current_employee_id or current_emplacement_id)

    # Volé uniquement si déjà affecté
    if requested_status == "STOLEN" and not has_assignment:
        raise HTTPException(
            status_code=400,
            detail="Un équipement ne peut être marqué Volé que s'il est déjà affecté"
        )

    # Assigné doit avoir une affectation
    if requested_status == "ASSIGNED" and not has_assignment:
        raise HTTPException(
            status_code=400,
            detail="Un équipement assigné doit avoir une affectation"
        )

    # Cohérence type / affectation
    if current_employee_id and not is_laptop:
        raise HTTPException(
            status_code=400,
            detail="Seuls les laptops peuvent être assignés à un employé"
        )

    if current_emplacement_id and is_laptop:
        raise HTTPException(
            status_code=400,
            detail="Les laptops doivent être assignés à un employé"
        )

    # Exclusivité affectation employé / emplacement
    if "employee_id" in payload and payload["employee_id"] is not None:
        payload["emplacement_id"] = None

    if "emplacement_id" in payload and payload["emplacement_id"] is not None:
        payload["employee_id"] = None

    # Si aucun statut fourni, on recalcule seulement par cohérence
    if "status" not in payload:
        payload["status"] = "ASSIGNED" if has_assignment else "IN_STOCK"

    # IN_STOCK libère toujours l'affectation
    elif requested_status == "IN_STOCK":
        payload["employee_id"] = None
        payload["emplacement_id"] = None

    # ASSIGNED garde une affectation obligatoire
    elif requested_status == "ASSIGNED":
        if not has_assignment:
            raise HTTPException(
                status_code=400,
                detail="Un équipement assigné doit avoir une affectation"
            )

    # MAINTENANCE : autorisé avec ou sans affectation
    elif requested_status == "MAINTENANCE":
        pass

    # STOLEN : on garde l'affectation
    elif requested_status == "STOLEN":
        if not has_assignment:
            raise HTTPException(
                status_code=400,
                detail="Un équipement ne peut être marqué Volé que s'il est déjà affecté"
            )

    old_employee_id = db_eq.employee_id
    new_employee_id = payload["employee_id"] if "employee_id" in payload else db_eq.employee_id

    for key, value in payload.items():
        setattr(db_eq, key, value)

    sync_employee_assignment_history(db, db_eq, old_employee_id, new_employee_id)

    db.commit()
    db.refresh(db_eq)
    return db_eq
@router.delete("/{equipment_id}")
def delete_equipment(
    equipment_id: int,
    db: Session = Depends(get_db),
    _=Depends(require_roles([UserRole.ADMIN]))   # 🔒 ADMIN uniquement
):
    db_eq = db.query(EquipmentModel).filter(EquipmentModel.id == equipment_id).first()
    if not db_eq:
        raise HTTPException(status_code=404, detail="Equipment not found")
    db.delete(db_eq)
    db.commit()
    return {"message": "Equipment deleted successfully"}

@router.post("/{equipment_id}/assign", response_model=EquipmentResponse)
def assign_equipment(
    equipment_id: int, employee_id: int,
    db: Session = Depends(get_db), _=Depends(get_current_active_user)
):
    eq = db.query(EquipmentModel).filter(EquipmentModel.id == equipment_id).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")
    old_employee_id = eq.employee_id
    eq.employee_id = employee_id
    eq.emplacement_id = None
    eq.status = "ASSIGNED"
    sync_employee_assignment_history(db, eq, old_employee_id, employee_id)
    db.commit()
    db.refresh(eq)
    return eq

@router.post("/{equipment_id}/unassign", response_model=EquipmentResponse)
def unassign_equipment(
    equipment_id: int,
    db: Session = Depends(get_db), _=Depends(get_current_active_user)
):
    eq = db.query(EquipmentModel).filter(EquipmentModel.id == equipment_id).first()
    if not eq:
        raise HTTPException(status_code=404, detail="Equipment not found")
    old_employee_id = eq.employee_id
    eq.employee_id = None
    eq.emplacement_id = None
    eq.status = "IN_STOCK"
    sync_employee_assignment_history(db, eq, old_employee_id, None)
    db.commit()
    db.refresh(eq)
    return eq
